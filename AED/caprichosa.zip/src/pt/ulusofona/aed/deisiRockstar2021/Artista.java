package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;

public class Artista {
    String nome;

    public Artista() { }

    public Artista(String nome) {
        this.nome = nome;
    }
}
