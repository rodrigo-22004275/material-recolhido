package pt.ulusofona.aed.deisiRockstar2021;

import static org.junit.Assert.*;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;

public class TestesMain {

    @Test
    public void testeParseInfo(){
        String real = new Song("23467723", "Hey Jude", new ArrayList<Artista>(), 1968, 0, false, 0, 0,0 ,0).toString();
        String esperado = "23467723 | Hey Jude | 1968";
        assertEquals("Resultado deveria ser '23467723 | Hey Jude | 1968'", esperado, real);
    }

    @Test
    public void testeParseInfo2(){
        String real = new Song("76623854", "California Dreamin'", new ArrayList<Artista>(), 1965, 0, false, 0, 0,0 ,0).toString();
        String esperado = "76623854 | California Dreamin' | 1965";
        assertEquals("Resultado deveria ser '76623854 | California Dreamin' | 1965'", esperado, real);
    }
}
