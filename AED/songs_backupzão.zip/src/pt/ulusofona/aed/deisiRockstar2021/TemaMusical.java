package pt.ulusofona.aed.deisiRockstar2021;

import java.util.ArrayList;

public class TemaMusical {
    String id;
    String titulo;
    ArrayList<Artista> artistas;
    int ano;
    int duracao;
    boolean explicita;
    int popularidade;
    int dancabilidade;
    int vivacidade;
    int volume;

    public TemaMusical(String id, String titulo, ArrayList<Artista> artistas, int ano, int duracao, boolean explicita, int popularidade, int dancabilidade, int vivacidade, int volume) {
        this.id = id;
        this.titulo = titulo;
        this.artistas = artistas;
        this.ano = ano;
        this.duracao = duracao;
        this.explicita = explicita;
        this.popularidade = popularidade;
        this.dancabilidade = dancabilidade;
        this.vivacidade = vivacidade;
        this.volume = volume;
    }

}
