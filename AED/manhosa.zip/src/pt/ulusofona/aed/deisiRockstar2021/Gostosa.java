package pt.ulusofona.aed.deisiRockstar2021;

import java.util.Scanner;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/*

O CÓDIGO ABAIXO É O CÓDIGO ORIGINAL SUBMETIDO DO DROP PROJECT COM OS TAIS 1500 ERROS.

 */


public class Gostosa {

    static ArrayList<Song> songs = new ArrayList<>();
    static ParseInfo pSongs = new ParseInfo();
    static ParseInfo pArtists = new ParseInfo();
    static ParseInfo pDetails = new ParseInfo();

    public static ArrayList<Artista> artistas(String id) {
        pArtists = new ParseInfo();
        ArrayList<Artista> artistas = new ArrayList<>();
        boolean emBranco = false;
        try {
            FileReader fr = new FileReader("song_artists.txt");
            BufferedReader reader = new BufferedReader(fr);

            String linha;
            while((linha = reader.readLine()) != null) {

                // partir a linha no caractere separador
                String[] dados = linha.split("@");

                // Ver se tem campos em branco
                for (int i = 0; i < dados.length; i++) {
                    if (dados[i].trim().equals("")) {
                        emBranco = true;
                        break;
                    }
                }

                // Guardar dados
                String num = dados[0].trim();
                if (dados.length == 2 && !emBranco) {
                    String[] arrayArtistas = dados[1].split("', '");
                    if (num.equals(id)) {
                        pArtists.ok++;
                        for (int i = 0; i < arrayArtistas.length; i++) {
                            arrayArtistas[i] = arrayArtistas[i].replace("\"", "");
                            arrayArtistas[i] = arrayArtistas[i].replace("['", "");
                            arrayArtistas[i] = arrayArtistas[i].replace("']", "");
                            artistas.add(new Artista(id, arrayArtistas[i].trim()));
                        }
                    } else {
                        pArtists.ok++;
                    }
                } else {
                    pArtists.ignoradas++;
                }
            }
            reader.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("Ficheiro não encontrado");
        }
        catch(IOException e) {
            System.out.println("Ocorreu um erro durante a leitura.");
        }

        return artistas;
    }

  public static Song maisDetalhes(Song song) {
        pDetails = new ParseInfo();
        boolean emBranco = false;
        try {
            FileReader fr = new FileReader("song_details.txt");
            BufferedReader reader = new BufferedReader(fr);

            String linha;
            while((linha = reader.readLine()) != null) {

                // partir a linha no caractere separador
                String[] dados = linha.split("@");

                // Guardar dados
                String num = dados[0].trim();

                // Ver se tem campos em branco
                for (int i = 0; i < dados.length; i++) {
                    if (dados[i].trim().equals("")) {
                        emBranco = true;
                        break;
                    }
                }

                // Verificar
                if(dados.length == 7 && !emBranco) {
                    pDetails.ok++;
                    if (num.equals(song.id)) {
                        song.duracao = Integer.parseInt(dados[1].trim());
                        song.explicita = Integer.parseInt(dados[2].trim()) != 0;
                        song.popularidade = Integer.parseInt(dados[3].trim());
                        song.dancabilidade = Double.parseDouble(dados[4].trim());
                        song.vivacidade = Double.parseDouble(dados[5].trim());
                        song.volume = Double.parseDouble(dados[6].trim());
                    }
                } else {
                    pDetails.ignoradas++;
                }
            }
            reader.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("Ficheiro não encontrado");
        }
        catch(IOException e) {
            System.out.println("Ocorreu um erro durante a leitura.");
        }

        return song;
    }

    public static void loadFiles() throws IOException {
        songs.clear();
        pSongs = new ParseInfo();
        pArtists = new ParseInfo();
        pDetails = new ParseInfo();

        boolean emBranco = false;
        try {
            FileReader fr = new FileReader("songs.txt");
            BufferedReader reader = new BufferedReader(fr);

            String linha;
            while((linha = reader.readLine()) != null) {

                // partir a linha no caractere separador
                String[] dados = linha.split("@");

                // Ver se tem campos em branco
                for (int i = 0; i < dados.length; i++) {
                    if (dados[i].trim().equals("")) {
                        emBranco = true;
                        break;
                    }
                }

                if (dados.length == 3 && Integer.parseInt(dados[2].trim()) <= 2021 && Integer.parseInt(dados[2].trim()) >= 0 && !emBranco) {
                    pSongs.ok++;
                    // Guardar dados
                    String id = dados[0].trim();
                    String titulo = dados[1].trim();
                    ArrayList<Artista> artistas = artistas(id);
                    int ano = Integer.parseInt(dados[2].trim());

                    /* // Mostrar o conteudo
                    System.out.println("\nID: " + id);
                    System.out.println("Título: " + titulo);
                    System.out.println("Artistas:");
                    artistas.forEach(artista -> {
                        System.out.println("  - " + artista.nome);
                    }); */

                    // criar o obj pt.ulusofona.aed.deisiRockstar2021.Song
                    Song song = new Song(id, titulo, artistas, ano, 0, false, 0, 0,0 ,0);

                    // acabar de preencher objeto criado anteriormente
                    songs.add(maisDetalhes(song));
                    songs.add(song);
                } else {
                    pSongs.ignoradas++;
                }

                /*
                De seguida seria necessário guardar o objecto
                Utilizador numa estrutura de dados apropriada
                (p.e. array, lista, etc).
                */
            }
            reader.close();
        }
        catch(FileNotFoundException e) {
            System.out.println("Ficheiro não encontrado");
        }
        catch(IOException e) {
            System.out.println("Ocorreu um erro durante a leitura.");
        }
    }

    public static ArrayList<Song> getSongs() {
        return songs;
    }

    public static ParseInfo getParseInfo(String fileName) {
        switch (fileName) {
            case "songs.txt":
                return pSongs;
            case "song_artists.txt":
                return pArtists;
            case "song_details.txt":
                return pDetails;
            default:
                return null;
        }
    }

    public static void main(String[] args) throws IOException {
        try {
            loadFiles();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            loadFiles();
        } catch (IOException e) {
            e.printStackTrace();
        }
        getSongs();
        System.out.println("Details: " + getParseInfo("song_details.txt").toString());
        System.out.println("Artists: " + getParseInfo("song_artists.txt").toString());
        System.out.println("  Songs: " + getParseInfo("songs.txt").toString());
    }

}
